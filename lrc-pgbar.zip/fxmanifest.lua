fx_version "adamant"
games { "rdr3" }
rdr3_warning "I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships."
lua54 "yes"

author 'Lircos - 1899'
description 'LRC - progress bar & timing minigame'
version '2.1.0'

shared_scripts {
    'config.lua',
}

client_scripts {
    'client/client.lua'
}

ui_page 'ui/index.html'

files {
    'ui/*',
    'ui/assets/*',
    'ui/assets/fonts/*',
}

