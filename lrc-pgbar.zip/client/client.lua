local queue          = {}
local cancelCallback = nil

local function _internalStart(message, miliseconds, cb, focus)
    if message == nil then message = PGBarConfig.DefaultProgressLabel end

    table.insert(queue, {
        message  = message,
        callback = cb,
        focus    = focus
    })

    if focus == nil or focus == true then
        SetNuiFocus(true, false)
    end

    SendNUIMessage({
        type    = 'open',
        message = message,
        mili    = miliseconds
    })
end

-- ── Exports ──────────────────────────────────────────────────

exports('initiate', function()
    local self = {}
    self.start    = _internalStart
    self.onCancel = function(cb) cancelCallback = cb end
    return self
end)

exports('cancelCurrentProgressBar', function()
    SendNUIMessage({ type = "cancel" })
    SetNuiFocus(false, false)
    queue = {}
end)

AddEventHandler('__cfx_export_progressBars_startUI', function(callback)
    callback(function(time, text)
        _internalStart(text, time, nil, false)
    end)
end)

-- ── NUI Callbacks ────────────────────────────────────────────

RegisterNUICallback('ProgressBar:Finish', function(args, nuicb)
    if queue[1] and queue[1].focus ~= false then
        SetNuiFocus(false, false)
    end
    if queue[1] and queue[1].callback then
        queue[1].callback()
    end
    table.remove(queue, 1)
    nuicb('ok')
end)

RegisterNUICallback('ProgressBar:Cancel', function(args, cb)
    if queue[1] and queue[1].focus ~= false then
        SetNuiFocus(false, false)
    end
    queue = {}
    if cancelCallback then cancelCallback() end
    cb('ok')
end)

-- ── StartProgress ─────────────────────────────────────────────
-- Synchronous. Blocks until the bar completes.
-- @param duration  number  Milliseconds
-- @param message   string  (optional) Label text
-- @return          boolean Always true on completion
exports('StartProgress', function(duration, message)
    local finished = false
    local success  = false

    _internalStart(message or PGBarConfig.DefaultProgressLabel, duration, function()
        finished = true
        success  = true
    end, false)

    while not finished do Wait(0) end
    return success
end)

-- ── StartTimingMinigame ───────────────────────────────────────
-- Synchronous. Player must press E inside the moving zone.
-- On failure the player is ragdolled briefly.
-- @param duration   number  (optional) Ms per round          (default: TimingDuration)
-- @param message    string  (optional) Label text            (default: DefaultTimingLabel)
-- @param rounds     number  (optional) Rounds to complete    (default: TimingRounds)
-- @param zoneWidth  number  (optional) Zone size % 1-100    (default: 20)
-- @return           boolean true = success, false = failed
local timingActive = false

exports('StartTimingMinigame', function(duration, message, rounds, zoneWidth)
    local finished = false
    local success  = false

    RegisterNUICallback('timing:result', function(data, cb)
        finished     = true
        success      = data.success
        timingActive = false
        SetNuiFocus(false, false)
        cb('ok')
        if not data.success then
            SetPedToRagdoll(PlayerPedId(), 1000, 1000, 0, 0, 0, 0)
        end
    end)

    timingActive = true
    SetNuiFocus(true, false)

    SendNUIMessage({
        type      = 'timing:open',
        message   = message   or PGBarConfig.DefaultTimingLabel,
        duration  = duration  or PGBarConfig.TimingDuration,
        rounds    = rounds    or PGBarConfig.TimingRounds,
        zoneWidth = zoneWidth or 20,
    })

    while not finished do Wait(0) end
    return success
end)


Citizen.CreateThread(function()
    while true do
        Wait(0)
        if timingActive then
            DisableAllControlActions(0)
            EnableControlAction(0, 0x07CE1E61, true)
            EnableControlAction(0, 0xA987235F, true)
        else
            Wait(500)
        end
    end
end)
