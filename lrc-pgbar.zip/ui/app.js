
(function () {
  'use strict';

  const progressContainer = document.getElementById('progress-container');
  const progressFill      = document.getElementById('progress-fill');
  const progressText      = document.getElementById('progress-text');

  const timingContainer   = document.getElementById('timing-container');
  const timingFill        = document.getElementById('timing-fill');
  const timingZoneEl      = document.getElementById('timing-zone');
  const timingText        = document.getElementById('timing-text');

  function show(el) { el.style.display = 'flex'; }
  function hide(el) { el.style.display = 'none'; }

  function post(endpoint, body) {
    fetch(`https://${GetParentResourceName()}/${endpoint}`, {
      method: 'POST',
      body: body ? JSON.stringify(body) : undefined,
    });
  }


  let progressTimeout = null;
  let progressRunning = false;

  function progressOpen(message, mili) {
    if (progressRunning) return;
    progressRunning = true;
    progressText.textContent = message;
    progressFill.style.animationDuration = mili + 'ms';
    progressFill.style.width = '0%';
    void progressFill.offsetWidth;
    progressFill.style.animation = 'none';
    void progressFill.offsetWidth;
    progressFill.style.animation = '';
    progressFill.style.animationDuration = mili + 'ms';
    show(progressContainer);
    progressTimeout = setTimeout(() => {
      progressRunning = false;
      hide(progressContainer);
      post('ProgressBar:Finish');
    }, mili);
  }

  function progressCancel() {
    if (progressTimeout) clearTimeout(progressTimeout);
    progressTimeout = null;
    progressRunning = false;
    hide(progressContainer);
  }

  let timingActive      = false;
  let timingRAF         = null;
  let timingStartTime   = null;
  let timingDuration    = 2200;
  let timingZoneWidth   = 20;
  let timingZoneLeft    = 20;
  let timingPressed     = false;
  let timingRoundsTotal = 1;
  let timingRoundsDone  = 0;
  let timingFillPct     = 0;

  function timingGenerateZone() {
    const max = 76 - timingZoneWidth;
    const min = 12;
    return min + Math.floor(Math.random() * (max - min));
  }

  function timingStartRound() {
    timingFillPct  = 0;
    timingPressed  = false;
    timingZoneLeft = timingGenerateZone();
    timingZoneEl.style.left = timingZoneLeft + '%';
    timingZoneEl.className  = 'timing-zone';
    timingZoneEl.src        = 'assets/partmg.png';
    timingFill.style.width  = '0%';
    timingStartTime = performance.now();
    timingActive    = true;
    show(timingContainer);
    timingRAF = requestAnimationFrame(timingTick);
  }

  function timingTick(now) {
    if (!timingActive) return;
    const elapsed = now - timingStartTime;
    timingFillPct = Math.min((elapsed / timingDuration) * 100, 100);
    timingFill.style.width = timingFillPct + '%';

    if (!timingPressed && timingFillPct > (timingZoneLeft + timingZoneWidth)) {
      timingPressed = true;
      timingZoneEl.className = 'timing-zone zone-fail';
      timingZoneEl.src = 'assets/partfail.png';
      setTimeout(() => timingFinish(false), 400);
      return;
    }
    if (timingFillPct >= 100 && !timingPressed) {
      timingZoneEl.className = 'timing-zone zone-fail';
      timingZoneEl.src = 'assets/partfail.png';
      setTimeout(() => timingFinish(false), 400);
      return;
    }
    timingRAF = requestAnimationFrame(timingTick);
  }

  function timingKeyPress() {
    if (!timingActive || timingPressed) return;
    timingPressed = true;
    cancelAnimationFrame(timingRAF);

    const now      = performance.now();
    const freshPct = Math.min(((now - timingStartTime) / timingDuration) * 100, 100);
    const inZone   = freshPct >= timingZoneLeft && freshPct <= (timingZoneLeft + timingZoneWidth);

    if (inZone) {
      timingZoneEl.className = 'timing-zone zone-success';
      timingZoneEl.src = 'assets/partsucces.png';
      timingRoundsDone++;
      if (timingRoundsDone >= timingRoundsTotal) {
        setTimeout(() => timingFinish(true), 350);
      } else {
        setTimeout(() => {
          hide(timingContainer);
          timingActive = false;
          setTimeout(() => timingStartRound(), 300);
        }, 350);
      }
    } else {
      timingZoneEl.className = 'timing-zone zone-fail';
      timingZoneEl.src = 'assets/partfail.png';
      setTimeout(() => timingFinish(false), 400);
    }
  }

  function timingFinish(success) {
    cancelAnimationFrame(timingRAF);
    timingActive = false;
    hide(timingContainer);
    post('timing:result', { success });
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'e' || e.key === 'E') {
      e.preventDefault();
      if (timingActive) timingKeyPress();
    }
  });

  window.addEventListener('message', function (e) {
    const d = e.data;
    if (d.type === 'open')   { progressOpen(d.message, d.mili); return; }
    if (d.type === 'cancel') { progressCancel(); return; }

    if (d.type === 'timing:open') {
      if (timingActive) return;
      timingText.textContent = d.message   || 'Press E in the marked zone!';
      timingDuration         = d.duration  || 2200;
      timingZoneWidth        = d.zoneWidth || 20;
      timingRoundsTotal      = d.rounds    || 1;
      timingRoundsDone       = 0;
      timingStartRound();
    }
  });

})();
