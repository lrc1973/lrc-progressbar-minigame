PGBarConfig = {}

-- ============================================================
--  PROGRESS BAR
-- ============================================================

-- Default label shown when no message is passed to StartProgress.
PGBarConfig.DefaultProgressLabel = "Please wait..."

-- ============================================================
--  TIMING MINIGAME
-- ============================================================

-- Default label shown when no message is passed to StartTimingMinigame.
PGBarConfig.DefaultTimingLabel = "Press E in the marked zone!"

-- How many rounds the player must complete to succeed.
PGBarConfig.TimingRounds = 1

-- Duration in milliseconds for each timing round.
-- Lower = faster = harder. Default: 2200.
PGBarConfig.TimingDuration = 2200
